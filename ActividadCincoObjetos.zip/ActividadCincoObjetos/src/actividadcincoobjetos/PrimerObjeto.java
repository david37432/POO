// jdk 18
package actividadcincoobjetos;
public class PrimerObjeto {
    String nombre = "DVR";
    String forma = "Rectangular";
    String materialDeFabricacion = "Plastico, matal y cobre";
    String TiposDeEntradas = "USB, de alarma, de audio, RS232  o RS5435" ;
    int NumeroDeEntradas = 4;
    public void FuncionObjeto(){
        String ConectarLasCamaras;
        String ConectarLasAlarmas;
        String TransmitirLaInformacionAUnTelevisor;
    }
    public void mostrarObjeto (){
        System.out.println("Contenido del objeto");
        System.out.println("nombre \t"+nombre);
        System.out.println("Forma del onjeto" + forma);
        System.out.println("Materiales de fabricacion" + materialDeFabricacion);
        System.out.println("Tipos de entradas" + TiposDeEntradas);
        System.out.println("Numero de etradas" + NumeroDeEntradas);
    }
    
    
    }

