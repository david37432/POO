// jdk 18
package actividadcincoobjetos;

public class CuartoObjeto {
    String nombre = "Sensor de Movimiento";
    String MaterialesDeFabricacion = "Plastico y metal";
    String Color = "Blanco y rojo";
    String Forma = "Rectangular";
    public void mostrarOnjeto(){
        System.out.println("Nombre: \t" + nombre);
        System.out.println("Forma del objeto:\t" + Forma);
        System.out.println("Color: \t" + Color);
        System.out.println("Materiales de fabricacion:\t" + MaterialesDeFabricacion);
    }
    public void FuncionObjeto(){
        String Detectar;
    }
}
