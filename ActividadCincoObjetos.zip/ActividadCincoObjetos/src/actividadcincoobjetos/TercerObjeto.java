// jdk 18
package actividadcincoobjetos;

public class TercerObjeto {
    String nombre = "camara";
    String forma = "Cilindrica";
    String color = "Blanco";
    String MaterialesDeFabricacion = "Vidrio, plastico y metal";
    public void mostrarObjeto(){
        System.out.println("Nombre: \t" + nombre);
        System.out.println("Forma del objeto:\t" + forma);
        System.out.println("Color: \t" + color);
        System.out.println("Materiales de fabricacion:\t" + MaterialesDeFabricacion);
    }
    public void FuncionObjeto(){
        String Grabar; 
        String TransmitirImagen;        
    }
    
    }

