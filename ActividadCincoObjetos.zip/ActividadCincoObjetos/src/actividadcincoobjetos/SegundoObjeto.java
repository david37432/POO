// jdk 18
package actividadcincoobjetos;
public class SegundoObjeto {
    String Nombre = "Disco duro";
    String MeterialDeFabricacion = "Silicona, cobre, aluminio, metal";
    String Forma = "Rectangular";
    String Color = "Plateado o negro";
    String DispositivosParaConectar = "Computadores";
    public void guardarInformacion () {
    
}
    public void mostrarObjeto(){
        System.out.println("Nombre: \t" + Nombre);
        System.out.println("Forma del objeto:\t" + Forma);
        System.out.println("Color: \t" + Color);
        System.out.println("Materiales de fabricacion:\t" + MeterialDeFabricacion);
    }
    }

