// jdk 18
package actividadcincoobjetos;

public class ActividadCincoObjetos {

    public static void main(String[] args) {
    PrimerObjeto  DVR = new PrimerObjeto ();
    SegundoObjeto DiscoDuro = new SegundoObjeto ();
    TercerObjeto Camara = new TercerObjeto ();
    CuartoObjeto SensorDeMovimiento = new CuartoObjeto ();
    QuintoObjeto Sirena = new QuintoObjeto ();
    DVR.mostrarObjeto();
    System.out.println("-------------");
    DiscoDuro.mostrarObjeto();
    System.out.println("-------------");
    Camara.mostrarObjeto();
    System.out.println("-------------");
    SensorDeMovimiento.mostrarOnjeto();
    System.out.println("-------------");
    Sirena.mostrarObjeto();
    }
    
}
