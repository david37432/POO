// jdk 18
package actividadcincoobjetos;

public class QuintoObjeto {

    String nombre = "Sirena";
    String Color = "Blanco";
    String Forma = "Cono truncado";
    String MaterialesDeFabricacion = "Plastico y metal";
    public void mostrarObjeto(){
        System.out.println("Nombre: \t" + nombre);
        System.out.println("Nombre: \t" + Color);
        System.out.println("Forma del onjeto: \t" + Forma);
        System.out.println("Materiales de fabricacion:\t" + MaterialesDeFabricacion);
    }
    public void FuncionObjeto(){
        String Alertar = "Alerta, Alerta Alerta";
        String Sonar = "UUUUUUUUUUUUU";
    }
}
